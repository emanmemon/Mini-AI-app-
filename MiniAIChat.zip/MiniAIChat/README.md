# Mini AI Chat (Android)

Chhota AI chat app: Kotlin + Jetpack Compose + Claude API.

## Setup
1. Android Studio me `File > Open` se is folder ko kholein, Gradle sync hone dein.
2. Project root me `local.properties` file me ye line add karein:
   `ANTHROPIC_API_KEY=sk-ant-xxxxxxxx`
   (API key https://console.anthropic.com se milti hai)
3. Emulator/phone pr Run karein.

> Note: `local.properties` .gitignore me hai, GitHub pr upload nahi hoti.
> Learning ke liye theek hai, lekin production app me key APK ke andar nahi rakhni chahiye (apna backend use karein).
