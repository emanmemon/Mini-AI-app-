package com.example.miniaichat

import com.example.miniaichat.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ClaudeApi {
    private val client = OkHttpClient.Builder()
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    /** history: list of (role, text) jahan role "user" ya "assistant" hai */
    suspend fun chat(history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        require(BuildConfig.API_KEY.isNotBlank()) {
            "API key missing: local.properties me ANTHROPIC_API_KEY=... likho"
        }
        val messages = JSONArray().apply {
            history.forEach { (role, text) ->
                put(JSONObject().put("role", role).put("content", text))
            }
        }
        val body = JSONObject()
            .put("model", "claude-haiku-5-5")
            .put("max_tokens", 1000)
            .put("system", "You are a friendly assistant. Reply in the user's language, keep it short.")
            .put("messages", messages)
            .toString()
            .toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", BuildConfig.API_KEY)
            .header("anthropic-version", "2023-06-01")
            .post(body)
            .build()

        client.newCall(request).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) error("API error ${resp.code}: $text")
            JSONObject(text).getJSONArray("content").getJSONObject(0).getString("text")
        }
    }
}
